package cs316project;

public abstract class FunDefList {
    public abstract void printParseTree (String indent);
}
