package cs316project;

public abstract class FunOp {
    public abstract void printParseTree(String indent) ;
}
