package cs316project;

public abstract class Exp {
    public abstract void printParseTree(String indent) ;
}
