package cs316project;

public class ParameterListEmpty extends ParameterList {
    public void printParseTree(String indent) {
        IO.println(indent +indent.length() + " <parameter list>");
    }
}
