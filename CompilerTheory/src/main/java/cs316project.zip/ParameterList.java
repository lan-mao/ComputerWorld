package cs316project;

public abstract class ParameterList {
    public abstract void printParseTree(String indent) ;
}
