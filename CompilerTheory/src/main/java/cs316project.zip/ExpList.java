package cs316project;

public abstract class ExpList {
    public abstract void printParseTree(String indent);
}
